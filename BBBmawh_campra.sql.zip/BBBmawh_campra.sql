-- phpMyAdmin SQL Dump
-- version 4.0.10.15
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-11-2017 a las 08:36:25
-- Versión del servidor: 5.1.68-community-log
-- Versión de PHP: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `BBBmawh_campra`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agencias`
--

CREATE TABLE IF NOT EXISTS `agencias` (
  `NumeAgen` int(11) NOT NULL,
  `NombAgen` varchar(100) DEFAULT NULL,
  `Imagen` varchar(200) DEFAULT NULL,
  `Dominio` varchar(20) DEFAULT NULL,
  `Direccion` varchar(500) DEFAULT NULL,
  `Telefono` varchar(50) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Facebook` varchar(100) DEFAULT NULL,
  `Twitter` varchar(100) DEFAULT NULL,
  `Instagram` varchar(100) DEFAULT NULL,
  `Posicion` varchar(200) DEFAULT NULL,
  `NumeAgenRegi` int(11) DEFAULT NULL,
  `ImagenFlyer` varchar(200) DEFAULT NULL,
  `Ocultar` bit(1) DEFAULT NULL,
  PRIMARY KEY (`NumeAgen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `agencias`
--

INSERT INTO `agencias` (`NumeAgen`, `NombAgen`, `Imagen`, `Dominio`, `Direccion`, `Telefono`, `Email`, `Facebook`, `Twitter`, `Instagram`, `Posicion`, `NumeAgenRegi`, `ImagenFlyer`, `Ocultar`) VALUES
(1, 'Campra Golf', 'imgAgencias/1.jpg', '/', 'Av. Padre Luchesse km 4.5 Villa Allende', '0351 156 640190', 'info@campragolf.com', 'https://www.facebook.com/CampraGolf', 'https://twitter.com/CampraGolf', 'https://www.instagram.com/campragolf', '-31.300455927672807,-64.26931786510977', 0, 'imgAgencias/1 - flyer.jpg', b'0');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `agenciasregistradas`
--

CREATE TABLE IF NOT EXISTS `agenciasregistradas` (
  `NumeAgen` int(11) NOT NULL,
  `NombComercial` varchar(200) NOT NULL,
  `Direccion` varchar(200) NOT NULL,
  `Telefono` varchar(100) NOT NULL,
  `PaginaWeb` varchar(200) DEFAULT NULL,
  `RazonSocial` varchar(200) NOT NULL,
  `IATA` varchar(20) DEFAULT NULL,
  `SECTUR` varchar(100) DEFAULT NULL,
  `RFC` varchar(100) NOT NULL,
  `NombAdmin` varchar(200) NOT NULL,
  `TeleAdmin` varchar(100) NOT NULL,
  `MailAdmin` varchar(200) NOT NULL,
  `NombVent` varchar(200) NOT NULL,
  `TeleVent` varchar(100) NOT NULL,
  `MailVent` varchar(200) NOT NULL,
  `NumeProv` int(11) DEFAULT NULL,
  `NumeEsta` int(11) NOT NULL,
  `FechAlta` datetime NOT NULL,
  PRIMARY KEY (`NumeAgen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bannerimagenes`
--

CREATE TABLE IF NOT EXISTS `bannerimagenes` (
  `NumeImag` int(11) NOT NULL,
  `NumeOrde` int(11) DEFAULT NULL,
  `NombImag` varchar(100) DEFAULT NULL,
  `Imagen` varchar(200) NOT NULL,
  `DescImag` text CHARACTER SET latin1,
  `Link` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`NumeImag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `bannerimagenes`
--

INSERT INTO `bannerimagenes` (`NumeImag`, `NumeOrde`, `NombImag`, `Imagen`, `DescImag`, `Link`) VALUES
(1, 1, 'China MÃ¡gica', 'imgBanner/1.jpg', 'Lo mejor de China', ''),
(2, 3, 'Vinos de Chile', 'imgBanner/2.jpg', '', ''),
(3, 2, '', 'imgBanner/3.jpg', 'lalalala', ''),
(4, 4, NULL, 'imgBanner/4.jpg', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `blog`
--

CREATE TABLE IF NOT EXISTS `blog` (
  `NumeBlog` int(11) NOT NULL,
  `Titulo` varchar(200) NOT NULL,
  `Dominio` varchar(50) NOT NULL,
  `Imagen` varchar(200) NOT NULL,
  `Copete` text CHARACTER SET latin1 NOT NULL,
  `Descripcion` text CHARACTER SET latin1 NOT NULL,
  `Fecha` datetime DEFAULT NULL,
  `Etiquetas` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`NumeBlog`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `blog`
--

INSERT INTO `blog` (`NumeBlog`, `Titulo`, `Dominio`, `Imagen`, `Copete`, `Descripcion`, `Fecha`, `Etiquetas`) VALUES
(1, 'Galápagos un lugar fascinante', 'galapagos-lugar-fascinante', 'imgBlog/previa - 1.jpg', 'El archipiélago de Galápagos es un lugar fascinante para practicar diversas actividades, tal, como la maravilla subacuática que es el buceo y el snorkel, que es la actividad más destacada de este archipiélago. Sus aguas cristalinas nos ofrecen la oportunidad para observar su diversa flora y fauna, así como sus arrecifes de coral, las ballenas, manta rayas, tiburones azules entre otros.', '<h3>El archipiélago de Galápagos es un lugar fascinante para practicar diversas actividades, tal, como &nbsp;la maravilla subacuática que es el buceo y el snorkel, que es la actividad más destacada de este archipiélago. Sus aguas cristalinas nos ofrecen la oportunidad para observar su diversa flora y fauna, así como sus arrecifes de coral, las ballenas, manta rayas, tiburones azules entre otros.<br></h3><h3>Interacciones Acuáticas</h3><span>En Galápagos, la interacción con los animales, es de las actividades más reconocidas y una de las especies más características son las tortugas gigantes, &nbsp;es tan natural y fascinante, los animales no demuestran ningún tipo de miedo ante la presencia humana o de otros animales lo que hace que tu experiencia sea aún más divertida e interesante.<br></span><br><b></b><b>¡Podrás disfrutar de la maravilla de nadar junto con los habitantes de estas aguas como los lobos marinos!<br></b><br><span>No te quedes con las ganas de probar nuevas experiencias y poder visitar “las tintoreras” donde es muy recomendable visitarla para poder realizar el snorkel. ¡Podrás disfrutar de la maravilla de nadar junto con los habitantes de estas aguas como los lobos marinos! Además, tú&nbsp; tienes la oportunidad de caminar con los diferentes animales del hábitat como los flamencos e iguanas por la gran ruta de Darwin.<br><br></span><h3>El encanto único de los paisajes</h3><span>En Isla Bartolme, ubicada al Norte de Santa Cruz, puedes disfrutar de las grandes vistas y paisajes con encanto único, además de poder disfrutar tu estancia sin la presencia de la gran variedad de fauna, muy buen lugar para poder disfrutar de la tranquilidad y el clima perfecto.<br></span><br><b></b><b>Si te gusta plasmar tus recuerdos en fotografías este es el lugar perfecto para las excelentes tomas que te ofrece esta hermosa isla.</b><br><br>', '2015-11-13 10:05:00', 'Andes, Galápagos, Ecuador'),
(2, 'articulo', 'asd', 'imgBlog/previa - 2.jpg', '', 'asdasda', '2015-11-13 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `blogcomentarios`
--

CREATE TABLE IF NOT EXISTS `blogcomentarios` (
  `NumeCome` int(11) NOT NULL,
  `NumeBlog` int(11) NOT NULL,
  `DescCome` text CHARACTER SET latin1 NOT NULL,
  `Fecha` datetime NOT NULL,
  `NumeUsua` int(11) DEFAULT NULL,
  `Nombre` varchar(200) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`NumeCome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `blogcomentarios`
--

INSERT INTO `blogcomentarios` (`NumeCome`, `NumeBlog`, `DescCome`, `Fecha`, `NumeUsua`, `Nombre`, `Email`) VALUES
(2, 1, 'Prueba', '2015-11-20 15:50:45', 1, NULL, NULL),
(3, 1, 'holaaaaa', '2015-12-22 10:00:00', NULL, 'Jose', 'jmperro@gmail.com'),
(4, 1, 'asdadas', '2015-12-22 11:44:12', NULL, 'juan', ''),
(5, 1, 'lalalal', '2015-12-22 11:47:58', NULL, 'pedro', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `blogexperiencias`
--

CREATE TABLE IF NOT EXISTS `blogexperiencias` (
  `NumeBlog` int(11) NOT NULL,
  `NumeExpe` int(11) NOT NULL,
  PRIMARY KEY (`NumeBlog`,`NumeExpe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `blogexperiencias`
--

INSERT INTO `blogexperiencias` (`NumeBlog`, `NumeExpe`) VALUES
(1, 1),
(1, 2),
(1, 3),
(2, 2),
(2, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `blogimagenes`
--

CREATE TABLE IF NOT EXISTS `blogimagenes` (
  `NumeImag` int(11) NOT NULL,
  `Imagen` varchar(200) NOT NULL,
  PRIMARY KEY (`NumeImag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `blogimagenes`
--

INSERT INTO `blogimagenes` (`NumeImag`, `Imagen`) VALUES
(1, 'imgBlog/1.png'),
(2, 'imgBlog/2.jpg'),
(3, 'imgBlog/3.png'),
(4, 'imgBlog/4.jpg'),
(5, 'imgBlog/5.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ciudades`
--

CREATE TABLE IF NOT EXISTS `ciudades` (
  `NumeCity` int(11) NOT NULL,
  `NombCity` varchar(100) DEFAULT NULL,
  `NumeRuta` int(11) DEFAULT NULL,
  PRIMARY KEY (`NumeCity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `ciudades`
--

INSERT INTO `ciudades` (`NumeCity`, `NombCity`, `NumeRuta`) VALUES
(1, 'México, DF.', 3),
(2, 'Morelia', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cotizaciones`
--

CREATE TABLE IF NOT EXISTS `cotizaciones` (
  `NumeCoti` int(11) NOT NULL,
  `FechCoti` date DEFAULT NULL,
  `NumeAgen` int(11) DEFAULT NULL,
  `NumeUsua` int(11) DEFAULT NULL,
  `Codigo` varchar(20) DEFAULT NULL,
  `NumeExpe` int(11) DEFAULT NULL,
  `NumeTour` int(11) DEFAULT NULL,
  `Nombre` varchar(200) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Telefono` varchar(200) DEFAULT NULL,
  `NumeProv` int(11) DEFAULT NULL,
  `Pasajero` varchar(200) DEFAULT NULL,
  `FechViaj` date DEFAULT NULL,
  `Origen` varchar(200) DEFAULT NULL,
  `Aereo` int(11) DEFAULT NULL,
  `AdulCant` int(11) DEFAULT NULL,
  `AdulEdad` varchar(200) DEFAULT NULL,
  `MenoCant` int(11) DEFAULT NULL,
  `MenoEdad` varchar(200) DEFAULT NULL,
  `InfaCant` int(11) DEFAULT NULL,
  `InfaEdad` varchar(200) DEFAULT NULL,
  `Comentario` text CHARACTER SET latin1,
  `NumeEsta` int(11) DEFAULT NULL,
  PRIMARY KEY (`NumeCoti`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `excursiones`
--

CREATE TABLE IF NOT EXISTS `excursiones` (
  `NumeExcu` int(11) NOT NULL,
  `Titulo` varchar(200) DEFAULT NULL,
  `Ciudad` varchar(200) DEFAULT NULL,
  `Descripcion` text CHARACTER SET latin1,
  `Precio` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`NumeExcu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `excursiones`
--

INSERT INTO `excursiones` (`NumeExcu`, `Titulo`, `Ciudad`, `Descripcion`, `Precio`) VALUES
(1, 'Callejoneada', 'Guanajato', 'Cita a la hora indicada en el Lobby del Hotel. Nos dirigiremos  al centro de la ciudad donde iniciaremos nuestro recorrido por los bellos callejones, calles empedradas y plazuelas del Guanajuato Nocturno, acompañados con la clásica estudiantina que nos trasladará a una época de Magia y Música. Durante nuestro recorrido nos ofrecerán una bebida en el típico porrón. Al terminar dicho recorrido, regresaremos  a nuestro Hotel.', '220 MXN'),
(2, 'Cantina Tapatías', 'Guadalajara', 'Guadalajara es famosa por sus películas de la época de oro con sus Charros, Tequilas y Cantinas.\r\nLe recomendamos, por ello, este tour por las cantinas que reviven esa época.                                                                           Por la tarde, nos daremos cita, en el lobby del hotel, para dirigirnos a la Plaza del Mariachi, donde apreciaremos bailes regionales y escucharemos las famosas músicas Tapatías. A continuación nos dirigiremos a las siguientes cantinas en las cuales degustaremos una bebida en cada una de ellas: La Fuente, una de las cantinas más antiguas, digna de conocerse por sus  anécdotas y la obligada leyenda de la bicicleta. Los Famosos Equipales, y Casa Bariachi.', '1000 MXN'),
(3, 'Leyendas de Morelia', 'Morelia', 'Cita a la hora indicada en el Lobby del Hotel para dirigirnos  al famoso recorrido de Las Leyendas de Morelia, este es un gran espectáculo teatral realizado con actores caracterizados quienes durante 3 hrs aprox.  nos narrarán diferentes Leyendas de sitios importantes de la ciudad. Al terminar regresaremos a nuestro Hotel.', '116 MXN');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `experiencias`
--

CREATE TABLE IF NOT EXISTS `experiencias` (
  `NumeExpe` int(11) NOT NULL,
  `NombExpe` varchar(100) NOT NULL,
  `Dominio` varchar(20) NOT NULL,
  `DescExpe` text CHARACTER SET latin1,
  `FotoBanner` varchar(100) NOT NULL,
  `FotoPortada` varchar(100) NOT NULL,
  `NumeEsta` int(11) NOT NULL,
  `NumeOrde` int(11) DEFAULT NULL,
  PRIMARY KEY (`NumeExpe`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `experiencias`
--

INSERT INTO `experiencias` (`NumeExpe`, `NombExpe`, `Dominio`, `DescExpe`, `FotoBanner`, `FotoPortada`, `NumeEsta`, `NumeOrde`) VALUES
(1, 'Bienestar', 'bienestar', 'El cuidado del cuerpo y el alma son esenciales para mantener el equilibrio físico y emocional y permitir que la energía fluya entre el mundo que nos rodea y nuestro propio ser. Vivir experiencias que enriquezcan no solo el cuerpo sino el alma, serán una inversión en tu propio crecimiento y bienestar. Libera el potencial que tienes para sentirte mejor, y vivir una experiencia renovadora.', 'imgExperiencias/1 - banner.jpg', 'imgExperiencias/1 - portada.jpg', 1, 3),
(2, 'School of Golf ', 'school-of-golf', 'Nuestros destinos te llevSchool of Golf consiste en una jornada de medio dÃ­a de aprendizaje & entrenamiento grupal guiada por el staff de instructores de Campra Golf en las magnÃ­ficas instalaciones de la Academia Campra Golf. \r\n\r\nEs una experiencia ideal para compartir con grupos de amigos y equipos de trabajo. Queremos que golfistas de todos los niveles disfruten como nunca antes el desafÃ­o de mejorar su golf! \r\n\r\nLa Academia Campra Golf estÃ¡ equipada con tecnologÃ­a de Ãºltima lÃ­nea que permite brindar instrucciÃ³n clara, concreta y precisa. Cuenta con las mejores herramientas y softwares en el mercado - cÃ¡maras de video de alta deï¬niciÃ³n, Boditrack, Trackman, V-1, K-Vest & Sam Putt Lab. Crea un espacio de encuentro y aprendizaje para todo tipo de golï¬stas y tambiÃ©n para aquellos que quieran iniciarse en el deporte. \r\n', 'imgExperiencias/2 - banner.jpg', 'imgExperiencias/2 - portada.jpg', 1, 2),
(3, 'Campra Viajes ', 'campra-viajes', 'Campra Golf introduce Campra Viajes! <br>\r\n\r\nOfrecemos viajes imperdibles que combinan el placer de jugar al golf en los bellÃ­simos campos de CÃ³rdoba con la experiencia Ãºnica de disfrutar una jornada de aprendizaje & entrenamiento exclusivo en la Academia Campra Golf.\r\n', 'imgExperiencias/3 - banner.jpg', 'imgExperiencias/3 - portada.jpg', 1, 1),
(4, 'Cultura e Historia', 'cultura', 'Nada como vivir, viajar y conocer para poderte formar un criterio sobre nuestra historia en este planeta. Descubre los rincones más exóticos y fascinantes para vivir experiencias que podrás heredar y compartir. Que nadie te platique lo que se vive del otro lado del mundo, ¡conócelo por ti mismo! Escoge un viaje diferente que te permita incrementar tus experiencias, que son ¡lo único que nos hace más ricos!', 'imgExperiencias/4 - banner.jpg', 'imgExperiencias/4 - portada.jpg', 1, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `flyers`
--

CREATE TABLE IF NOT EXISTS `flyers` (
  `NumeFlyer` int(11) NOT NULL,
  `NombFlyer` varchar(200) DEFAULT NULL,
  `Imagen` varchar(200) NOT NULL,
  `NumeTour` int(11) NOT NULL,
  PRIMARY KEY (`NumeFlyer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `flyers`
--

INSERT INTO `flyers` (`NumeFlyer`, `NombFlyer`, `Imagen`, `NumeTour`) VALUES
(1, 'Prueba', 'imgFlyers/1.png', 2),
(2, '', 'imgFlyers/2.jpg', -1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hoteles`
--

CREATE TABLE IF NOT EXISTS `hoteles` (
  `NumeHotel` int(11) NOT NULL,
  `NombHotel` varchar(200) DEFAULT NULL,
  `Cadena` varchar(200) DEFAULT NULL,
  `Ciudad` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`NumeHotel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `hoteles`
--

INSERT INTO `hoteles` (`NumeHotel`, `NombHotel`, `Cadena`, `Ciudad`) VALUES
(1, 'Misión Express Zona Rosa', 'Misión', 'México DF'),
(2, 'Misión El Molino', 'Misión', 'San Miguel de Allende'),
(3, 'Misión Guanajato', 'Misión', 'Guanajato');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `itinerarios`
--

CREATE TABLE IF NOT EXISTS `itinerarios` (
  `NumeItin` int(11) NOT NULL,
  `NumeTour` int(11) NOT NULL,
  `NombItin` varchar(200) NOT NULL,
  PRIMARY KEY (`NumeItin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `itinerarios`
--

INSERT INTO `itinerarios` (`NumeItin`, `NumeTour`, `NombItin`) VALUES
(1, 1, 'ITINERARIO EMPEZANDO EN QUITO'),
(2, 1, 'ITINERARIO EMPEZANDO EN GUAYAQUIL'),
(3, 2, 'ITINERARIO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `itinerariosdetalles`
--

CREATE TABLE IF NOT EXISTS `itinerariosdetalles` (
  `NumeItin` int(11) NOT NULL,
  `NumeDia` int(11) NOT NULL,
  `NombDia` varchar(100) DEFAULT NULL,
  `DescDia` text CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`NumeItin`,`NumeDia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `itinerariosdetalles`
--

INSERT INTO `itinerariosdetalles` (`NumeItin`, `NumeDia`, `NombDia`, `DescDia`) VALUES
(1, 1, 'Lunes', 'Traslado Aeropuerto / Hotel en Quito. Alojamiento.'),
(1, 2, 'Martes', 'Desayuno en el hotel. Excursión al Mercado de Otavalo Salida desde Quito por la vía Panamericana Norte vía a Cayambe, pasamos por Guachalá (ex monumento a la mitad del Mundo).  Los pasajeros tendrán la posibilidad de degustar los deliciosos “Bizcochos de Cayambe”, un tipo de galleta o pan, elaborado en horno de barro (acompañados de queso de hoja o dulce de leche).   Tendremos luego, una breve parada en “Miralago”, para admirar una maravillosa vista del Lago San Pablo, seguimos hasta llegar a Otavalo donde los indígenas nativos de la zona, “Otavalos”, elaboran sus tejidos.\r\nQuienes así lo deseen, podrán elegir entre quedarse en esta zona y nuestro bus los recogerá al regreso de Cotacachi (no tendrán esta visita) o continuar con el recorrido hacia Cotacachi, muy reconocida por confección y artesanías de cuero.  Aquí tendrán tiempo suficiente para visitar el pueblo, las tiendas de artículos de cuero y tiempo libre para almorzar.  Regreso a Quito, recogiendo a los pasajeros que se quedaron en Otavalo (punto y hora de encuentro establecido por el guía de Gray line Ecuador), por la vía Cajas – Tabacundo. \r\n\r\n** Bus esperará por un tiempo de 10 minutos en Otavalo para recoger a los pasajeros que se quedaron en esa parada, posterior a eso regresará a Quito con quienes estén a bordo.'),
(1, 3, 'Miercoles', 'Desayuno en el hotel. City Tour (Quito City Explorer - 1 Day Pass + Mitad del Mundo)\r\nRecorrido turístico a lo largo de las zonas más importantes de la ciudad, centros comerciales y zona rosa “La Mariscal”, donde se encuentran gran parte de los hoteles de Quito. Continuamos hacía el Centro Histórico para visitar sus iglesias y atracciones más importantes, donde usted podrá visitar los sitios que sean de su mayor interés, explorando  cada uno de sus rincones a su propio ritmo desde la puerta de su hotel, disfrutando profundamente de aquellos temas que son de su interés: música, arquitectura, culturas vivas, gastronomía, artesanía, fotografía, compras, observación de atractivos turísticos y paisajes únicos, pero sobre todo, compartir con las costumbres de nuestra gente y vivir experiencias únicas en nuestra ciudad. (No incluye entradas) mayor información en www.quitocityexplorer.com. La extensión incluida continúa hacia el norte, llegaremos a la Mitad del Mundo (Incluye entrada) donde se podrá observar el monumento que divide el hemisferio norte del hemisferio sur del planeta. Fue construida en el siglo XVIII donde la expedición científica francesa definió la posición exacta de la línea Ecuador que divide al mundo. Como alternativa se podrá visitar el “Museo Intiñan”, conocido como el Museo de la Cultura Solar Equinoccial o el Museo Etnográfico (no incluye entradas).'),
(1, 4, 'sfdsfs', 'sdfsdfsdafdasf'),
(1, 5, '', 'asdasdas'),
(2, 1, 'Jueves', 'Traslado Aeropuerto / Hotel en Guayaquil. Alojamiento.'),
(2, 2, 'Viernes', 'Desayuno en hotel. Traslado hotel / Aeropuerto en Guayaquil, para tomar el vuelo (no incluido) a Galápagos. \r\nRecepción en el aeropuerto de Baltra y traslado en buses de servicio gratuito hasta el muelle del canal Itabaca, para cruzar en ferry de servicio público a la Isla Santa Cruz, donde un transporte estará esperándolos para trasladarlos hasta Puerto Ayora, zona donde se encuentran los hoteles de esta isla. En la vía, tendrán la oportunidad de conocer los túneles de lava y una reserva de tortugas gigantes. Visita la estación científica Charles Darwin donde podrá conocer más sobre las islas Galápagos, las especies que en ella habitan, su formación y evolución, los programas de conservación y observar algunas tortugas gigantes en cautiverio(Traslado opera diario a las 12:30Pm, excepto domingos a las 13:30Pm).'),
(3, 1, 'Viernes ', 'Encuentro @ Aeropuerto Internacional CÃ³rdoba. Traslado a hotel & check in *opcional\r\n11 hs Traslado a Valle del Golf \r\n12:30 hs Almuerzo @ Restaurant Valle \r\n13:45 hs Golf @ Valle del Golf\r\n19:30 hs Traslado a hotel '),
(3, 2, 'Sabado', '10 a 13 hs School of Golf @ Campra Golf  \r\n13:30 hs Almuerzo@ Villa Golf  \r\n15:30 hs Traslado a hotel'),
(3, 3, 'Domingo', '9:30 hs Golf @ CÃ³rdoba Golf Club \r\n14:30 hs Almuerzo @ CGC Restaurant \r\n17 hs Traslado a Aeropuerto Internacional CÃ³rdoba *opcional ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincias`
--

CREATE TABLE IF NOT EXISTS `provincias` (
  `NumeProv` int(11) NOT NULL,
  `NombProv` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`NumeProv`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `provincias`
--

INSERT INTO `provincias` (`NumeProv`, `NombProv`) VALUES
(1, 'Aguascalientes'),
(2, 'Baja California'),
(3, 'Baja California Sur'),
(4, 'Campeche'),
(5, 'Coahuila'),
(6, 'Colima'),
(7, 'Chiapas'),
(8, 'Chihuahua'),
(9, 'Ciudad de México'),
(10, 'Durango'),
(11, 'Guanajuato'),
(12, 'Guerrero'),
(13, 'Hidalgo'),
(14, 'Jalisco'),
(15, 'Estado de México'),
(16, 'Michoacán'),
(17, 'Morelos'),
(18, 'Nayarit'),
(19, 'Nuevo León'),
(20, 'Oaxaca'),
(21, 'Puebla'),
(22, 'Querétaro'),
(23, 'Quintana Roo'),
(24, 'San Luis Potosí'),
(25, 'Sinaloa'),
(26, 'Sonora'),
(27, 'Tabasco'),
(28, 'Tamaulipas'),
(29, 'Tlaxcala'),
(30, 'Veracruz'),
(31, 'Yucatán'),
(32, 'Zacatecas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutasmexico`
--

CREATE TABLE IF NOT EXISTS `rutasmexico` (
  `NumeRuta` int(11) NOT NULL,
  `Nombre` varchar(100) DEFAULT NULL,
  `Descripcion` text CHARACTER SET latin1,
  `Descripcion2` text CHARACTER SET latin1,
  `ImgPrevia` varchar(200) DEFAULT NULL,
  `ImgPortada` varchar(200) DEFAULT NULL,
  `ImgMapaGrande` varchar(200) DEFAULT NULL,
  `ImgMapaChico` varchar(200) DEFAULT NULL,
  `ImgReferencias` varchar(200) DEFAULT NULL,
  `Dominio` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`NumeRuta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `rutasmexico`
--

INSERT INTO `rutasmexico` (`NumeRuta`, `Nombre`, `Descripcion`, `Descripcion2`, `ImgPrevia`, `ImgPortada`, `ImgMapaGrande`, `ImgMapaChico`, `ImgReferencias`, `Dominio`) VALUES
(1, 'Ruta Prehispana', 'Una espectacular travesía por los principales sitios turísticos de Chiapas y la Riviera Maya, visitando Chichen Itza una de las 7 maravillas del mundo moderno.', '<div class="text-center">\r\n<strong>\r\nRuta Independencia R11 10 días saliendo de Cuidad de México\r\n<br>\r\nDesde: $19,971 MXN por persona en habitación doble\r\n</strong>\r\n<br>\r\n<table class="table table-condensed table-striped table-bordered">\r\n<tr>\r\n<th>CIUDAD</th>\r\n<th>ESTANCIA</th>\r\n</tr>\r\n<tr>\r\n<td>CIUDAD DE MEXICO</td>\r\n<td>3 NOCHES</td>\r\n</tr>\r\n<tr>\r\n<td>SAN MIGUEL DE ALLENDE</td>\r\n<td>1 NOCHE</td>\r\n</tr>\r\n<tr>\r\n<td>GUANAJUATO</td>\r\n<td>2 NOCHES</td>\r\n</tr>\r\n<tr>\r\n<td>ZACATECAS</td>\r\n<td>1 NOCHE</td>\r\n</tr>\r\n<tr>\r\n<td>GUADALAJARA</td>\r\n<td>1 NOCHE</td>\r\n</tr>\r\n<tr>\r\n<td>MORELIA</td>\r\n<td>1 NOCHE</td>\r\n</tr>\r\n</table>\r\n</div>', 'imgRutasMexico/1 - previa.jpg', 'imgRutasMexico/1 - portada.jpg', 'imgRutasMexico/1 - mapagrande.jpg', 'imgRutasMexico/1 - mapachico.jpg', 'imgRutasMexico/1 - referencias.png', 'ruta-prehispana'),
(2, 'Ruta Maya', 'Una espectacular travesía por los principales sitios turísticos de Chiapas y la Riviera Maya, visitando Chichen Itza una de las 7 maravillas del mundo moderno.', NULL, 'imgRutasMexico/2 - previa.jpg', 'imgRutasMexico/2 - portada.jpg', 'imgRutasMexico/2 - mapagrande.jpg', 'imgRutasMexico/2 - mapachico.jpg', NULL, 'ruta-maya'),
(3, 'Ruta Independencia', 'Visita las joyas coloniales de México, como Dolores Hidalgo “cuna de la independencia”, los pueblos mágicos de San Miguel de Allende, Patzcuaro y atotonilco; las ciudades más emblemáticos de esa época de la historia mexicana.', NULL, 'imgRutasMexico/3 - previa.jpg', 'imgRutasMexico/3 - portada.jpg', 'imgRutasMexico/3 - mapagrande.jpg', 'imgRutasMexico/3 - mapachico.jpg', NULL, 'ruta-independencia');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutasmexicobanner`
--

CREATE TABLE IF NOT EXISTS `rutasmexicobanner` (
  `NumeImag` int(11) NOT NULL,
  `NumeOrde` int(11) DEFAULT NULL,
  `Imagen` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`NumeImag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `rutasmexicobanner`
--

INSERT INTO `rutasmexicobanner` (`NumeImag`, `NumeOrde`, `Imagen`) VALUES
(1, 1, 'imgRutasMexicoBanner/1.jpg'),
(2, 2, 'imgRutasMexicoBanner/2.jpg'),
(3, 3, 'imgRutasMexicoBanner/3.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutasmexicodias`
--

CREATE TABLE IF NOT EXISTS `rutasmexicodias` (
  `NumeDia` int(11) NOT NULL,
  `NumeRuta` int(11) NOT NULL,
  `Ciudades` varchar(500) DEFAULT NULL,
  `Descripcion` text CHARACTER SET latin1,
  `Imagen` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`NumeDia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `rutasmexicodias`
--

INSERT INTO `rutasmexicodias` (`NumeDia`, `NumeRuta`, `Ciudades`, `Descripcion`, `Imagen`) VALUES
(1, 1, 'México, DF.', 'Llegada al Distrito Federal, traslado desde el lugar de llegada al hotel programado. Cena y Alojamiento.', 'imgRutasMexicoDias/1.jpg'),
(2, 1, 'México, DF.', 'Desayuno. En la mañana tiempo libre para descansar y pasear por el centro de la ciudad. En la tarde, visita de la ciudad conociendo el centro histórico, Paseo de la Reforma, Chapultepec, Plaza México. Cena y Alojamiento.', 'imgRutasMexicoDias/2.jpg'),
(3, 1, 'ciudad1', 'prueba', 'imgRutasMexicoDias/3.jpg'),
(4, 2, 'lala', 'lala', ''),
(5, 2, 'pepepep', 'pepepepe', ''),
(6, 2, 'asdasdas', 'asdasa', ''),
(7, 1, 'Morelia', 'wwwwwwwwwwwwww', 'imgRutasMexicoDias/7.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutasmexicogaleria`
--

CREATE TABLE IF NOT EXISTS `rutasmexicogaleria` (
  `NumeImag` int(11) NOT NULL,
  `NumeRuta` int(11) NOT NULL,
  `NumeOrde` int(11) DEFAULT NULL,
  `Imagen` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`NumeImag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `rutasmexicogaleria`
--

INSERT INTO `rutasmexicogaleria` (`NumeImag`, `NumeRuta`, `NumeOrde`, `Imagen`) VALUES
(1, 1, 1, 'imgRutasMexicoGaleria/1 - 1.png'),
(2, 1, 2, 'imgRutasMexicoGaleria/1 - 2.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutasmexicoitinerarios`
--

CREATE TABLE IF NOT EXISTS `rutasmexicoitinerarios` (
  `NumeItin` int(11) NOT NULL,
  `NumeRuta` int(11) DEFAULT NULL,
  `Codigo` varchar(100) DEFAULT NULL,
  `Precio` varchar(100) DEFAULT NULL,
  `CiudadFin` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`NumeItin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `rutasmexicoitinerarios`
--

INSERT INTO `rutasmexicoitinerarios` (`NumeItin`, `NumeRuta`, `Codigo`, `Precio`, `CiudadFin`) VALUES
(1, 1, 'R11', '15000 MXN', 'Morelia'),
(2, 2, 'R11A', '5000 MXN', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutasmexicoitinerariosdetalles`
--

CREATE TABLE IF NOT EXISTS `rutasmexicoitinerariosdetalles` (
  `NumeItin` int(11) NOT NULL,
  `NumeDia` int(11) NOT NULL,
  `NumeOrde` int(11) DEFAULT NULL,
  `DiaSemana` int(11) DEFAULT NULL,
  `Fin` bit(1) DEFAULT NULL,
  PRIMARY KEY (`NumeItin`,`NumeDia`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `rutasmexicoitinerariosdetalles`
--

INSERT INTO `rutasmexicoitinerariosdetalles` (`NumeItin`, `NumeDia`, `NumeOrde`, `DiaSemana`, `Fin`) VALUES
(1, 1, 1, 1, b'0'),
(1, 2, 2, 2, b'0'),
(1, 3, 3, 3, b'0'),
(1, 7, 5, 4, b'1'),
(2, 4, 1, 2, b'0'),
(2, 5, 2, 3, b'0'),
(2, 6, 3, 4, b'1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutasmexicoitinerariosexcursiones`
--

CREATE TABLE IF NOT EXISTS `rutasmexicoitinerariosexcursiones` (
  `NumeItin` int(11) NOT NULL,
  `NumeExcu` int(11) NOT NULL,
  PRIMARY KEY (`NumeItin`,`NumeExcu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `rutasmexicoitinerariosexcursiones`
--

INSERT INTO `rutasmexicoitinerariosexcursiones` (`NumeItin`, `NumeExcu`) VALUES
(1, 1),
(1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutasmexicoitinerarioshoteles`
--

CREATE TABLE IF NOT EXISTS `rutasmexicoitinerarioshoteles` (
  `NumeItin` int(11) NOT NULL,
  `NumeHotel` int(11) NOT NULL,
  `Estancia` int(11) DEFAULT NULL,
  PRIMARY KEY (`NumeItin`,`NumeHotel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `rutasmexicoitinerarioshoteles`
--

INSERT INTO `rutasmexicoitinerarioshoteles` (`NumeItin`, `NumeHotel`, `Estancia`) VALUES
(1, 1, 2),
(1, 2, 1),
(1, 3, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tours`
--

CREATE TABLE IF NOT EXISTS `tours` (
  `NumeTour` int(11) NOT NULL,
  `NombTour` varchar(200) NOT NULL,
  `Dominio` varchar(20) NOT NULL,
  `Lugares` varchar(500) DEFAULT NULL,
  `Copete` text CHARACTER SET latin1,
  `Subtitulo` varchar(200) NOT NULL,
  `Duracion` varchar(200) NOT NULL,
  `NumeExpe` int(11) NOT NULL,
  `DescTour` text CHARACTER SET latin1,
  `Precio` varchar(100) DEFAULT NULL,
  `Vigencia` varchar(200) DEFAULT NULL,
  `Articulo` varchar(200) DEFAULT NULL,
  `Imagen` varchar(200) NOT NULL,
  `Portada` varchar(200) NOT NULL,
  `EnPromo` bit(1) NOT NULL,
  `AbrirLink` bit(1) NOT NULL,
  `Posicion` varchar(200) DEFAULT NULL,
  `NumeEsta` int(11) NOT NULL,
  `Codigo` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`NumeTour`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tours`
--

INSERT INTO `tours` (`NumeTour`, `NombTour`, `Dominio`, `Lugares`, `Copete`, `Subtitulo`, `Duracion`, `NumeExpe`, `DescTour`, `Precio`, `Vigencia`, `Articulo`, `Imagen`, `Portada`, `EnPromo`, `AbrirLink`, `Posicion`, `NumeEsta`, `Codigo`) VALUES
(2, 'Tres DÃ­as de Golf ', 'tres-dias-de-golf', 'Valle del Golf, School of Golf @ Campra Golf , CÃ³rdoba Golf Club ', 'Nuestros paquetes GOLF EN CÃ“RDOBA incluyen: Hospedaje en hotel . Traslados in - out & cancha de golf - hotel. Green fees.  Caddies o Golf Carts. Almuerzos. Souvenir Campra Golf. Asistencia Permanente Durante la Jornada. School of Golf ', 'Nuestros paquetes GOLF EN CÃ“RDOBA incluyen: ', '2 Noches Y 3 DÃ­as', 3, 'Hospedaje en tu hotel  Traslados in - out & cancha de golf - hotel. Green fees.  Caddies o Golf Carts. Almuerzos. Souvenir Campra Golf. Asistencia Permanente Durante la Jornada. School of Golf ', 'Tarifa por persona: $8.608 + IVA \r\n* el valor de la tarifa es para grupos de ocho personas y varÃ­a ', '1 de Noviembre de 2017 al 31 de Marzo del 2018', 'imgTours/2 - articulo.jpg', 'imgTours/2 - imagen.jpg', 'imgTours/2 - portada.jpg', b'0', b'1', '', 1, 'ITM01'),
(3, 'Yoga Tours India', 'yoga-tours-india', 'Delhi ï¿½ Varanasi ï¿½ Khajuraho ï¿½ Agra ï¿½ Jaipur - Delhi', '', 'INDIA YOGA TOUR', '10 Dï¿½as y 9 noches', 3, 'Te invitamos a vivir la experiencia de practicar yoga en cada ciudad que visitas rodeado de la cultura que la vio nacer, de los paisajes que inspiraron su creaciï¿½n. Domina tu mente e inspira a tu espï¿½ritu visitando las principales ciudades, templos y palacios, participa de algunos rituales que te transportarï¿½n a otra ï¿½poca. Vive, siente, medita y aprende.', '$2,241 USD por persona en ocupaciï¿½n doble', '1 de Octubre 2015 al 15 de Abril del 2016', 'imgTours/3 - articulo.jpg', 'imgTours/3 - imagen.jpg', 'imgTours/3 - portada.jpg', b'0', b'0', '', 1, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tourscomentarios`
--

CREATE TABLE IF NOT EXISTS `tourscomentarios` (
  `NumeCome` int(11) NOT NULL,
  `NumeTour` int(11) NOT NULL,
  `PuntCome` int(11) NOT NULL,
  `DescCome` text CHARACTER SET latin1 NOT NULL,
  `NumeUsua` int(11) DEFAULT NULL,
  `Fecha` datetime NOT NULL,
  `Nombre` varchar(200) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`NumeCome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tourscomentarios`
--

INSERT INTO `tourscomentarios` (`NumeCome`, `NumeTour`, `PuntCome`, `DescCome`, `NumeUsua`, `Fecha`, `Nombre`, `Email`) VALUES
(1, 2, 9, 'Excelente!', 1, '2015-11-19 00:00:00', NULL, NULL),
(2, 2, 10, 'Buenisimo!', 1, '2015-11-20 16:25:33', NULL, NULL),
(3, 2, 4, '4 puntos', 1, '2015-11-24 12:00:38', NULL, NULL),
(4, 2, 6, '888888', NULL, '2015-12-22 10:00:00', 'Jose', 'jmperro@gmail.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `toursdocumentacion`
--

CREATE TABLE IF NOT EXISTS `toursdocumentacion` (
  `NumeDocu` int(11) NOT NULL,
  `NumeTour` int(11) NOT NULL,
  `DescDocu` varchar(200) NOT NULL,
  PRIMARY KEY (`NumeDocu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `toursgaleria`
--

CREATE TABLE IF NOT EXISTS `toursgaleria` (
  `NumeImag` int(11) NOT NULL,
  `NumeTour` int(11) NOT NULL,
  `Imagen` varchar(200) NOT NULL,
  `NombImag` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`NumeImag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `toursincluye`
--

CREATE TABLE IF NOT EXISTS `toursincluye` (
  `NumeIncl` int(11) NOT NULL,
  `NumeTour` int(11) NOT NULL,
  `FlagIncl` bit(1) NOT NULL,
  `DescIncl` varchar(500) NOT NULL,
  PRIMARY KEY (`NumeIncl`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `NumeUsua` int(11) NOT NULL,
  `NombComp` varchar(50) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `NombMail` varchar(100) NOT NULL,
  `NombUsua` varchar(50) DEFAULT NULL,
  `NombPass` varchar(10) DEFAULT NULL,
  `TipoUsua` int(11) NOT NULL COMMENT '1: Admin - 2: Agencia - 3: Usuario - 4: Newsletter',
  `NumeEsta` int(11) NOT NULL,
  `FechAlta` datetime NOT NULL,
  `NumeUsuaRefe` int(11) DEFAULT NULL,
  `NumeAgen` int(11) NOT NULL,
  `chkBanners` bit(1) DEFAULT NULL,
  `chkAgencias` bit(1) DEFAULT NULL,
  `chkAgRegistros` bit(1) DEFAULT NULL,
  `chkExperiencias` bit(1) DEFAULT NULL,
  `chkTours` bit(1) DEFAULT NULL,
  `chkBlog` bit(1) DEFAULT NULL,
  `chkFlyers` bit(1) DEFAULT NULL,
  `chkCotizaciones` bit(1) DEFAULT NULL,
  `chkUsuarios` bit(1) DEFAULT NULL,
  PRIMARY KEY (`NumeUsua`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`NumeUsua`, `NombComp`, `NombMail`, `NombUsua`, `NombPass`, `TipoUsua`, `NumeEsta`, `FechAlta`, `NumeUsuaRefe`, `NumeAgen`, `chkBanners`, `chkAgencias`, `chkAgRegistros`, `chkExperiencias`, `chkTours`, `chkBlog`, `chkFlyers`, `chkCotizaciones`, `chkUsuarios`) VALUES
(1, 'JosÃ© Romero', 'jose.romero@vector-it.com.ar', 'JROMERO', 'jose', 1, 1, '2015-12-04 00:00:00', NULL, 0, b'1', b'1', b'1', b'1', b'1', b'1', b'1', b'1', b'1'),
(2, 'Jorge Lacuara', 'jlacuara@hotmail.com', 'jlacuara', 'jorge', 1, 1, '2017-11-09 09:24:37', 1, -1, b'1', b'1', b'1', b'1', b'1', b'1', b'1', b'1', b'1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
